package com.project.fashionrental.dto;

public class ProductUpdateRequest {
    
}
