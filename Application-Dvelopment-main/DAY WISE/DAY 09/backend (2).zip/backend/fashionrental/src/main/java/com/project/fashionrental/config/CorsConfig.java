package com.project.fashionrental.config;

public class CorsConfig {
    
}
